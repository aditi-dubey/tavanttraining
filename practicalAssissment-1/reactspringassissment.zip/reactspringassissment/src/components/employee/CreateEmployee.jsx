//rafcp
import React ,{useState,useEffect} from 'react'
import PropTypes from 'prop-types'
import axios from "axios"
import {
    Button,
    Card,
    CardBody,
    CardFooter,
    Form,
    Input,
    InputGroup,
    InputGroupAddon,
    InputGroupText,
    Row
}from "reactstrap"


const CreateEmployee = (props) => {

   const [employee, setEmployee] = useState(
       {
           employeeId:"",
           firstName:"",
           lastName:"",
           extension:"",
           email:"",
           officeCode:"",
           jobTitle:"",
       }
   )
   const [showLoading, setShowLoading] = useState(false)
   const {
          
    employeeId,
    firstName,
    lastName,
    extension,
    email,
    officeCode,
    jobTitle,

   }=employee;
    const apiUrl="http://localhost:8080/api/employee/"

   const onChange=(e)=>{
        setEmployee({...employee,[e.target.name]:e.target.value});
    }

   const onSubmit=(e)=>{
        e.preventDefault();
        axios.post(apiUrl,employee).then((res)=>props.history.push("/employeelist"));
        
    };

    return (
        <div>
            <Form onSubmit={onSubmit}>
                <InputGroup className="mb-3">
                   <Input
                     type="text"
                     name="employeeId"
                     id="employeeId"
                     placeholder="employeeId"
                     value={employeeId}
                     onChange={onChange}
                   />
                </InputGroup >


                <InputGroup>
                   <Input
                     type="text"
                     name="firstName"
                     id="firstName"
                     placeholder="firstName"
                     value={firstName}
                     onChange={onChange}
                   />
                </InputGroup>



                <InputGroup className="mb-3">
                   <Input
                     type="text"
                     name="lastName"
                     id="lastName"
                     placeholder="lastName"
                     value={lastName}
                     onChange={onChange}
                   />
                </InputGroup>

             <InputGroup className="mb-3">
                   <Input
                     type="text"
                     name="extension"
                     id="extension"
                     placeholder="extension"
                     value={extension}
                     onChange={onChange}
                   />
                </InputGroup>


                <InputGroup className="mb-3"> 
                   <Input
                     type="email"
                     name="email"
                     id="email"
                     placeholder="email"
                     value={email}
                     onChange={onChange}
                   />
                </InputGroup>


                <InputGroup className="mb-3">
                   <Input
                     type="text"
                     name="officeCode"
                     id="officeCode"
                     placeholder="officeCode"
                     value={officeCode}
                     onChange={onChange}
                   />
                </InputGroup>



                
                <InputGroup className="mb-3">
                   <Input
                     type="text"
                     name="jobTitle"
                     id="jobTitle"
                     placeholder="jobTitle"
                     value={jobTitle}
                     onChange={onChange}
                   />
                </InputGroup>


                <Button className="btn btn-info mb-1" block>
                    <span>Save</span>
                </Button>
            </Form>

        </div>
    )
}

CreateEmployee.propTypes = {

}

export default CreateEmployee;
