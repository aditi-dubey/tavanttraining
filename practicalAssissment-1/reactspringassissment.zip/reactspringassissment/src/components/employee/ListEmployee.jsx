//rafcp
import React from 'react'
import PropTypes from 'prop-types'
import axios from "axios"
import {useState,useEffect} from "react";
import {
    Badge,
    Card,
    CardBody,
    CardHeader,
    CardFooter,Col,
    Pagination,
    PaginationItem,
    PaginationLink,
    Row,
    Table,
}from "reactstrap";

const ListEmployee = (props) => {

    const [data, setData] = useState([]);
    useEffect(() => {
        const GetData=async()=>{
        const result= await axios.get("http://localhost:8080/api/all");
        console.log(result.data);
        setData(result.data)
        };
        GetData();
    }, [])


    const deleteEmployee=(id)=>{
        axios.delete("http://localhost:8080/api/"+id).then((result=>{
            props.history.push("/");
        }))
    }
    return (
        <div className="animated fadeIn"> 
           <Table>
                 
           <thead>
                <tr>
                    <th>EmployeeId</th>
                    <th>firstName</th>
                    <th>lastName</th>
                    <th>extension</th>
                    <th>email</th>
                    <th>officeCode</th>
                    <th>jobTitle</th>
                </tr>
               
            </thead>

          <tbody>
               {   data.map(
                     (employees,id)=>{
                         
                       <tr>
                       <td>{employees.employeeId}</td>
                       <td>{employees.firstName}</td>
                       <td>{employees.lastName}</td>
                        <td>{employees.extension}</td>
                        <td>{employees.email}</td>
                        <td>{employees.officeCode}</td>
                        <td>{employees.jobTitle}</td>
                        <td> <button onClick={
                        ()=>{
                          
                         }
                        }Edit
                    > </button></td>
                      <td> 
                        <button onClick={
                        ()=>{
                            deleteEmployee(employees.employeeId)
                        }
                        }Delete
                        > </button></td>

<td> 
                        <button onClick={
                        ()=>{
                           
                        }
                        }edit
                        > </button></td>
                   </tr>
                     }  
                 )
                }
           </tbody>
          
              
           </Table>
        </div>
    )
}

ListEmployee.propTypes = {

}

export default ListEmployee
