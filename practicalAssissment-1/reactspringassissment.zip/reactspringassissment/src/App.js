import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router,Switch,Route, Link} from "react-router-dom";
import CreateEmployee from "./components/employee/CreateEmployee";
import ListEmployee from "./components/employee/ListEmployee";
import EditEmployee from "./components/employee/EditEmployee"; 

function App() {
  return (
   <div className="App">
      <Router>
        <div className="container">
          <nav className="btn btn-warning navbar-expand-lg navheader">
            <div className="collapse navbar-collapse">
              <ul className="navbar-nv mr-auto">
                <li className="nav-item">
                  <Link to={"/createemployee"} className="nav-link">
                    Add Employee
                  </Link>
                </li>

                <li className="nav-item">
                  <Link to={"/employeelist"} className="nav-link">
                    List Employee
                  </Link>
                </li>

              </ul>
            </div>
          </nav>
           <Switch>
             <Route exact path="/createemployee" component={CreateEmployee}></Route>
             <Route exact path="/employeelist" component={ListEmployee}></Route>
             <Route exact path="/edit/:id" component={EditEmployee}></Route>
            </Switch>
          </div>
      </Router>
    </div>
  );
}

export default App;
